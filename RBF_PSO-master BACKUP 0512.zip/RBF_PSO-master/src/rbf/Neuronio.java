package rbf;

public class Neuronio {

}
